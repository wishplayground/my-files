package lk.ijse.dep11;

public class AppInitiallizerWrapper {
    public static void main(String[] args) {
        AppInitalizer.main(args);
    }
}
