package lk.ijse.dep11;

import java.io.Serializable;

public class Table implements Serializable {
    private String code;
    private String discription;
    private int qty;
    private double price;
    private double total;

    public Table(String code, String discription, int qty, double price, double total) {
        this.setCode(code);
        this.setDiscription(discription);
        this.setQty(qty);
        this.setPrice(price);
        this.setTotal(total);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
