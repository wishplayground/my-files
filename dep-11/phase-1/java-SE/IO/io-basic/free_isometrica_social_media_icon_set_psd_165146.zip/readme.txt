                                                                     
   8888b.  888d888 .d8888b 88888b.   .d88b.  888d888 888  888  8888b.  
      "88b 888P"  d88P"    888 "88b d8P  Y8b 888P"   888  888     "88b
  .d888888 888    888      888  888 88888888 888     Y88  88P .d888888
  888  888 888    Y88b.    888  888 Y8b.     888      Y8bd8P  888  888
  "Y888888 888     "Y8888P 888  888  "Y8888  888       Y88P   "Y888888

		   ISOMETRICA SOCIAL ICONS - VOLUME 1
			  
			  http://arcnerva.com

--------------------------------------------------------------------------

04.10.10

Arcnerva in partnership with Six Revisions is proud to bring you the
Isometrica Social Icons set Volume 1. There are two folders, one with
normal size icons and one with a smaller set organized into .PNG files.
There are 18 files in each set. We have also included a .psd file to 
help make resizing easier. Social networking sites and/or icon types
included in this release:

Delicious
Design Bump
Digg
Facebook
Flickr
Friend Feed
Google
LastFM
Linked In
Newsvine
Reddit
RSS Feed
Stumble Upon
Technoratti
Tumblr
Twitter
Vimeo

Feel free to use them for Non Commercial projects. If you use them for
commercial purposes we wouldnt mind a link back to us at arcnerva.com
but they are free for commercial use as well.

Questions? Comments?
Check us out at arcnerva.com, visit our blog at arcnerva.com/blog/, or
send us an email at mail@arcnerva.com.

Special thanks:
Jacob Gube and Six Revisions (sixrevisions.com).
