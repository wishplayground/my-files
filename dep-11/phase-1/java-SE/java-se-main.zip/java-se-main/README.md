# Java SE
Let's explore the Java SE library. Are you ready?

### License
Copyright &copy; 2023 DEP-11. All Rights Reserved.
