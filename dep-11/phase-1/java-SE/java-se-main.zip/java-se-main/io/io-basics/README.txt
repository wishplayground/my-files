Input Output Basics (I/O) 
 Welcome to DEP-10