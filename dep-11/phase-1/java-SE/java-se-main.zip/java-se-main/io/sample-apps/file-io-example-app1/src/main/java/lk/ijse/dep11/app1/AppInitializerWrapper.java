package lk.ijse.dep11.app1;

public class AppInitializerWrapper {
    public static void main(String[] args) {
        AppInitializer.main(args);
    }
}
